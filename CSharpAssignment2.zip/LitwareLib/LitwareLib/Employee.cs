﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LitwareLib
{
	internal class Employee
	{
		private int _empNo;
		private String _empName;
		private double _salary;

		private double _HRA;
		private double _TDS;
		private double _DA;
		private double _PF;
		private double _TA;

		private double _netSalary;
		private double _grossSalary;
		public Employee(int empNo, String empName, double salary)
		{
			this._empNo = empNo;
			this._empName = empName;
			this._salary = salary;
		}
		public int getEmpNo()
		{
			return _empNo;
		}
		public String getEmpName()
		{
			return _empName;
		}
		public double getSalary()
		{
			return _salary;
		}

		public double calculateGrossSalary()
		{
			try
			{
				if (_salary < 5000)
				{
					_grossSalary = _salary + ((_salary / 100) * 10) + ((_salary / 100) * 5) + ((_salary / 100) * 15);
				}
				else if (_salary < 10000)
				{
					_grossSalary = _salary + ((_salary / 100) * 15) + ((_salary / 100) * 10) + ((_salary / 100) * 20);
				}
				else if (_salary < 15000)
				{
					_grossSalary = _salary + ((_salary / 100) * 20) + ((_salary / 100) * 15) + ((_salary / 100) * 25);
				}
				else if (_salary < 20000)
				{
					_grossSalary = _salary + ((_salary / 100) * 25) + ((_salary / 100) * 20) + ((_salary / 100) * 30);
				}
				else if (_salary >= 20000)
				{
					_grossSalary = _salary + ((_salary / 100) * 30) + ((_salary / 100) * 25) + ((_salary / 100) * 35);
				}
			}
			catch (ArithmeticException exc1)
			{
				Console.WriteLine("Arithmetic Exception Occured", exc1);

			}
			catch (Exception exc)
			{
				Console.WriteLine("Exception occured", exc);
			}

			return _grossSalary;
		}

		public void calculateSalary()
		{
			try
			{
				_PF = (_grossSalary / 100) * 10;
				_TDS = (_grossSalary / 100) * 18;
				_netSalary = _grossSalary - (_PF + _TDS);
			}
			catch (ArithmeticException exc2)
			{
				Console.WriteLine("Arithmetic Exception Occured", exc2);

			}
			catch (Exception exc3)
			{
				Console.WriteLine("Exception occured", exc3);

			}
			finally
			{
				Console.WriteLine("PF: {0}", _PF);
				Console.WriteLine("TDS: {0}", _TDS);
				Console.WriteLine("netSalary: {0}", _netSalary);
				Console.ReadLine();
			}
		}
		public static void Main(string[] args)
		{

			Employee S = new Employee(10, "sai kiran", 20000.0);
			Console.WriteLine(S.calculateGrossSalary());

		}

	}

}